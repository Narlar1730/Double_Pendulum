import javax.swing.*;

/**
 * Created by ErikT on 08-Feb-17.
 */
class Ball extends JPanel {


    static double                     x = 500;
    static double                     y = 500;
    static int                x_bar_top = 533;
    static int                y_bar_top = 0;
    static double                 ticks = 0;
    static double                    Rx = 0;
    static double                    Ry = 0;
    public static double        omega_x = 500;
    public static double        omega_y = 500;
    public static int       omega_top_x = 533;
    public static int       omega_top_y = 0;

    /*CHANGE ME*/
    // Please also note that the notation is terrible, but I will attempt to explain. rmass means red mass, and is the pendulum attached to the central pivot
    // x_dot is the velocity of x
    // x_dub is the acceleration of x
    // Anything labelled as a 2 is attached to the second pendulum
    // Anything labelled with a 1 is attached to the first pendulum
    private static double    rgravity = 40;
    private static double      length = 100;
    private static double      theta  = toRad(10);
    static double           theta_dot = 0;
    private static double   theta_dub = 0;
    private static double       rmass = 10;
    private static double        mass = 10;
    private static double    Inertia1 = (1/12) * rmass*length*length;
    private static double    length_2 = 50;
    private static double         psi = toRad(10);
    static double             psi_dot = 0;
    private static double     psi_dub = 0;
    private static double    Inertia2 = (1/12) * mass*length_2*length_2;
    //This is used if you want to calculate the lyapunov exponents
    private static boolean  calc_lyap = false;
    private static int  lyapunov_time = 5000;

    //The following is the code for the second set of double pendulum, designed to show the difference between the two. Set USE_TWO to true in order to see it in action.
    public  static boolean USE_TWO      = false;
    private static double  omega_length = 100;
    private static double         omega = toRad(180);
    private static double     omega_dot = 0;
    private static double     omega_dub = 0;
    private static double    omega_mass = 10;
    private static double omega_Inertia = (1/12) * omega_mass*omega_length*omega_length;
    public static double          eta_x = 500;
    public static double          eta_y = 300;
    private static double    eta_length = 50;
    private static double           eta = toRad(181);
    private static double       eta_dot = 0;
    private static double       eta_dub = 0;
    private static double      eta_mass = 10;
    private static double   eta_Inertia = (1/12) * eta_mass*eta_length*eta_length;

    /*STOP CHANGING*/

    static int flips = 0;
    private static double previousPsi = 0;
    private static double dt     = 0.01;
    private static double firstPsi = psi;
    private static double FinalPsi = 0;

    private static double sin (double angle){
        return Math.sin((angle));
    }

    private static double cos (double angle){
        return Math.cos((angle));
    }

    private static double toRad (double angle){
        return Math.toRadians(angle);
    }

    private static double toCorrectDomain (double angle){
        while(angle >= 360){
            angle = angle -360;
        }
        while(angle <= 0){
            angle = angle + 360;
        }
        return angle;
    }

    private static void Calculate_Lyapunov (){
        double lambda = (1/ticks)*Math.log(FinalPsi/firstPsi);
        System.out.println(lambda);

    }

    static void moveBall() {
        //Please note that the c substitutions were made here because I kept making mistakes writing the equations of motion, so this made things much easier for me.
        // They are correct as far as I can tell, and it just made life much simpler to program, even though they aren't used in the report.
        double c1 = rmass*length*length/2 + Inertia1/2 + mass*length*length/2;
        double c2 = mass*length_2*length_2/2 +Inertia2/2;
        double c3 = mass*length*length_2;
        double c4 = rgravity *(rmass*length+mass*length);
        double c5 = rgravity *mass*length_2;

        previousPsi = psi;
        psi_dub = (mass*length*length_2*theta_dot*psi_dot*sin(theta-psi)-mass* rgravity *length_2*sin(psi)-mass*length*length_2*theta_dub*cos(theta-psi)+mass*length*length_2*theta_dot*(theta_dot-psi_dot)*sin(theta-psi))/(Inertia2+mass*length_2*length_2);
        psi_dot = (psi_dot + psi_dub*dt);
        psi     = (psi + psi_dot*dt);
        if (ticks == lyapunov_time && calc_lyap){
            FinalPsi = psi;
            Calculate_Lyapunov();
        }

        theta_dub = (2*c2*c4*sin(theta)+c3*c3*theta_dot*theta_dot*sin(theta-psi)*cos(theta-psi)+2*c2*c3*psi_dot*psi_dot*sin(theta-psi)-c3*c5*cos(theta-psi)*sin(psi))/(c3*c3*cos(theta-psi)*cos(theta-psi)-4*c1*c2);
        theta_dot = (theta_dot + theta_dub*dt);
        theta     = (theta + theta_dot*dt);

        Rx = length*Math.sin((theta))+ 525;
        Ry = length*Math.cos((theta))+200;


        if(window.BVelocity.size()<1600) {
            if(theta_dot>2){
                window.RVelocity.add(2.0);
            }
            else if(theta_dot<-1){
                window.RVelocity.add(-1.0);
            }
            else {
                window.RVelocity.add(theta_dot);
            }

            if(psi_dot>2){
                window.BVelocity.add(2.0);
            }
            else if(psi_dot<-1){
                window.BVelocity.add(-1.0);
            }
            else {
                window.BVelocity.add(psi_dot);
            }
        }
        double previouspsi = toCorrectDomain(Math.toDegrees(previousPsi));
        double currentpsi  = toCorrectDomain(Math.toDegrees(psi));
        if (previouspsi < 180 && currentpsi >= 180 && previouspsi > 40){
            flips++;
        }
        else if(previouspsi > 180 && currentpsi <= 180 && previouspsi < 320){
            flips++;

        }


        x = length_2*(Math.sin(psi)) + Rx;
        y = length_2*(Math.cos(psi)) + Ry;

    }

/**
 * This entire method is basically just a copy of the first one, so there isn't anything commented in here. For more detail, please see the method moveBall
 */
    static void move_Omega() {

        double c1 = omega_mass*omega_length*omega_length/2 + omega_Inertia/2 + eta_mass*omega_length*omega_length/2;
        double c2 = eta_mass*eta_length*eta_length/2 +eta_Inertia/2;
        double c3 = eta_mass*omega_length*eta_length;
        double c4 = rgravity *(omega_mass*omega_length+eta_mass*omega_length);
        double c5 = rgravity *omega_mass*eta_length;

        eta_dub = (eta_mass*omega_length*eta_length*omega_dot*eta_dot*sin(omega-eta)-eta_mass* rgravity * eta_length*sin(eta)-eta_mass*omega_length*eta_length*omega_dub*cos(omega-eta)+eta_mass*omega_length*eta_length*omega_dot*(omega_dot-eta_dot)*sin(omega-eta))/(eta_Inertia+eta_mass*eta_length*eta_length);
        eta_dot = (eta_dot + eta_dub*dt);
        eta     = (eta + eta_dot*dt);

        omega_dub = (2*c2*c4*sin(omega)+c3*c3*omega_dot*omega_dot*sin(omega-eta)*cos(omega-eta)+2*c2*c3*eta_dot*eta_dot*sin(omega-eta)-c3*c5*cos(omega-eta)*sin(eta))/(c3*c3*cos(omega-eta)*cos(omega-eta)-4*c1*c2);
        omega_dot = (omega_dot + omega_dub*dt);
        omega     = (omega + omega_dot*dt);

        omega_x = omega_length*Math.sin((omega))+ 525;
        omega_y = omega_length*Math.cos((omega))+200;


        if(window.OVelocity.size()<1600) {
            if(omega_dot>2){
                window.OVelocity.add(2.0);
            }
            else if(omega_dot<-1){
                window.OVelocity.add(-1.0);
            }
            else {
                window.OVelocity.add(omega_dot);
            }

            if(eta_dot>2){
                window.EVelocity.add(2.0);
            }
            else if(eta_dot<-1){
                window.EVelocity.add(-1.0);
            }
            else {
                window.EVelocity.add(eta_dot);
            }
        }

        eta_x = eta_length*(Math.sin(eta)) + omega_x;
        eta_y = eta_length*(Math.cos(eta)) + omega_y;

    }
}
