import java.awt.*;

import static java.awt.Color.black;

/**
 * Created by ErikT on 25-Mar-17.
 * This is where some really cool fun stuff happens - I swear just trust me for now and roll with it.
 * That was entirely a joke
 */
class Chaos {


    private static int Number_of_cycles = 2000;
    private static int    current_cycle =    0;

/*
The following are all the initial conditions of the chaos map. They are named the same as in the ball class because I couldn't be bothered to type it all
out again and just copy and pasted. You are welcome to change them to build different chaos maps, but remember it takes a long time to build a new map.
On average about ~2 minutes on my computer.
if you want a suggestion for something that turns out to be really fun, just leave them how they start out. It creates a really pretty picture.
 */
    private static double    rgravity = 40;
    private static double      length = 100;
    private static double      theta  = Ball.toRad(90);
    static double           theta_dot = 0;
    private static double   theta_dub = 0;
    private static double       rmass = 10;
    private static double        mass = 10;
    private static double    Inertia1 = (1/12) * rmass*length*length;
    private static double    length_2 = 100;
    private static double         psi = Ball.toRad(90);
    static double             psi_dot = 0;
    private static double     psi_dub = 0;
    private static double    Inertia2 = (1/12) * mass*length_2*length_2;
    static int                  flips = 0;
    private static double previousPsi = 0;
    private static double          dt = 0.01;
    private static int      max_flips = 0;


    /**
     * This method chooses the colour of chaos. It counts the flips in a set timeframe from a given angle // Programmers note - Doesn't that sound cool? Deciding the colour of chaos?
     * This is set at 2000 cycles which is about 20 seconds on my computer.
     * @param angle_1 this is the first angle of the upper pendulum
     * @param angle_2 this is the second angle of the pendulum
     * @return a colour that is used in the map, depending on number of flips. It will choose varying shades of blue depending on the amount of flips. The brighter the blue colour, the more flips. After 10 flips it will
     * assume that everything is the same colour.
     *
     */
        public static Color colour_of_chaos (double angle_1, double angle_2){
            // This is the colour that we will return at the end. It is initialised as black because if something goes wrong at least black is slimming.
            Color end_point = black;
            /*
              So to explain what is going on in the next section will require some words, I will do my best to make it as breif as possible.
              In essence what this method does is takes two angles, then simulates what will happen over a desgnated time. It will sum the flips,
              and then depending on how many flips are reecorded it will return a colour value. The more flips, the brighter the colour.
              It uses the exact same physics as the other methods in the code, going through the same double pendulum cycle.
              The only difference is that it runs through a while loop to count the flips.
              The 2000 cycles was chosen arbitrarily because it is about twenty seconds on my computer.
             */
            double c1 = rmass*length*length/2 + Inertia1/2 + mass*length*length/2;
            double c2 = mass*length_2*length_2/2 +Inertia2/2;
            double c3 = mass*length*length_2;
            double c4 = rgravity *(rmass*length+mass*length);
            double c5 = rgravity *mass*length_2;

            psi   = Ball.toRad(angle_2);
            theta = Ball.toRad(angle_1);


            while(current_cycle<Number_of_cycles) {

                previousPsi = psi;
                psi_dub = (mass * length * length_2 * theta_dot * psi_dot * Ball.sin(theta - psi) - mass * rgravity * length_2 * Ball.sin(psi) - mass * length * length_2 * theta_dub * Ball.cos(theta - psi) + mass * length * length_2 * theta_dot * (theta_dot - psi_dot) * Ball.sin(theta - psi)) / (Inertia2 + mass * length_2 * length_2);
                psi_dot = (psi_dot + psi_dub * dt);
                psi = (psi + psi_dot * dt);

                theta_dub = (2 * c2 * c4 * Ball.sin(theta) + c3 * c3 * theta_dot * theta_dot * Ball.sin(theta - psi) * Ball.cos(theta - psi) + 2 * c2 * c3 * psi_dot * psi_dot * Ball.sin(theta - psi) - c3 * c5 * Ball.cos(theta - psi) * Ball.sin(psi)) / (c3 * c3 * Ball.cos(theta - psi) * Ball.cos(theta - psi) - 4 * c1 * c2);
                theta_dot = (theta_dot + theta_dub * dt);
                theta = (theta + theta_dot * dt);

                double previouspsi = Ball.toCorrectDomain(Math.toDegrees(previousPsi));
                double currentpsi = Ball.toCorrectDomain(Math.toDegrees(psi));
                if (previouspsi < 180 && currentpsi >= 180 && previouspsi > 40) {
                    flips++;
                } else if (previouspsi > 180 && currentpsi <= 180 && previouspsi < 320) {
                    flips++;
                }
                current_cycle++;
            }
            if (flips > max_flips){
                max_flips = flips;
                System.out.println("New Max flips at: " + angle_1 + ", " + angle_2);
            }
            System.out.println("flips: " + flips + ", max_flips: " + max_flips);
            if(flips>20){
                end_point = new Color(255, 255, 255);
            }
            else if(flips > 10){

                end_point = new Color(25*(flips-10), 25*(flips-10), 255);
            }
            else{
                end_point = new Color(0, 0, flips * 25);
            }
            current_cycle = 0;
            flips         = 0;
            theta_dot = 0;
            theta_dub = 0;
            psi_dot = 0;
            psi_dub = 0;
            previousPsi = 0;

            return end_point;

        }
}
