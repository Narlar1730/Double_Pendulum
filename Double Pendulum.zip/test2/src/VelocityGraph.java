import java.awt.*;

import static java.awt.Color.black;

/**
 * Created by ErikT on 28-Mar-17.
 */
public class VelocityGraph {
    private static int Number_of_cycles = 2000;
    private static int    current_cycle =    0;


    private static double    rgravity = 40;
    private static double      length = 100;
    private static double      theta  = Ball.toRad(90);
    static double           theta_dot = 0;
    private static double   theta_dub = 0;
    private static double       rmass = 10;
    private static double        mass = 10;
    private static double    Inertia1 = (1/12) * rmass*length*length;
    private static double    length_2 = 100;
    private static double         psi = Ball.toRad(90);
    static double             psi_dot = 0;
    private static double     psi_dub = 0;
    private static double    Inertia2 = (1/12) * mass*length_2*length_2;
    private static double VelocitySum = 0;
    private static double          dt = 0.01;



    public static double average_velocity (double length_of_rod){

        current_cycle = 0;
        theta_dot = 0;
        theta_dub = 0;
        psi_dot = 0;
        psi_dub = 0;

        double c1 = rmass*length*length/2 + Inertia1/2 + mass*length*length/2;
        double c2 = mass*length_2*length_2/2 +Inertia2/2;
        double c3 = mass*length*length_2;
        double c4 = rgravity *(rmass*length+mass*length);
        double c5 = rgravity *mass*length_2;

        psi = Ball.toRad(90);
        theta = Ball.toRad(90);

        while(current_cycle<Number_of_cycles) {

            psi_dub = (mass * length * length_2 * theta_dot * psi_dot * Ball.sin(theta - psi) - mass * rgravity * length_2 * Ball.sin(psi) - mass * length * length_2 * theta_dub * Ball.cos(theta - psi) + mass * length * length_2 * theta_dot * (theta_dot - psi_dot) * Ball.sin(theta - psi)) / (Inertia2 + mass * length_2 * length_2);
            psi_dot = (psi_dot + psi_dub * dt);
            psi = (psi + psi_dot * dt);

            theta_dub = (2 * c2 * c4 * Ball.sin(theta) + c3 * c3 * theta_dot * theta_dot * Ball.sin(theta - psi) * Ball.cos(theta - psi) + 2 * c2 * c3 * psi_dot * psi_dot * Ball.sin(theta - psi) - c3 * c5 * Ball.cos(theta - psi) * Ball.sin(psi)) / (c3 * c3 * Ball.cos(theta - psi) * Ball.cos(theta - psi) - 4 * c1 * c2);
            theta_dot = (theta_dot + theta_dub * dt);
            theta = (theta + theta_dot * dt);

            /*if(psi_dot > 0){
                VelocitySum = VelocitySum + psi_dot;
            }
            else{
                VelocitySum = VelocitySum - psi_dot;
            }*/
            VelocitySum = VelocitySum + psi_dot;

            current_cycle++;
        }
        return (VelocitySum/current_cycle);


    }
}
