import java.util.LinkedList;

/**
 * Created by ErikT on 28-Mar-17.
 *
 * I am pretty sure that this is done wrong but owell.
 *
 * It is supposed to produce a lyapunov graph, and then print out the average of the system, but I think there is a mistake in my working somewhere.
 *
 */
public class Lyaponuv {
    private static int Number_of_cycles = 2000;
    private static int    current_cycle =    0;

    public static LinkedList<Double> Exponents = new LinkedList<>();
    public static LinkedList<Double> Averages  = new LinkedList<>();


    private static double     rgravity = 40;
    private static double       length = 100;
    private static double       theta  = Ball.toRad(10);
    static double            theta_dot = 0;
    private static double    theta_dub = 0;
    private static double        rmass = 10;
    private static double         mass = 10;
    private static double     Inertia1 = (1/12) * rmass*length*length;
    private static double     length_2 = 100;
    private static double          psi = Ball.toRad(10);
    static double              psi_dot = 0;
    private static double      psi_dub = 0;
    private static double     Inertia2 = (1/12) * mass*length_2*length_2;
    private static double           dt = 0.01;


    private static double  omega_length = 100;
    private static double         omega = Ball.toRad(10);
    private static double     omega_dot = 0;
    private static double     omega_dub = 0;
    private static double    omega_mass = 10;
    private static double omega_Inertia = (1/12) * omega_mass*omega_length*omega_length;
    private static double    eta_length = 100;
    private static double           eta = Ball.toRad(10);
    private static double       eta_dot = 0;
    private static double       eta_dub = 0;
    private static double      eta_mass = 10;
    private static double   eta_Inertia = (1/12) * eta_mass*eta_length*eta_length;


    public static double Average (LinkedList<Double> list){
        double total = 0;
        for(int i = 0; i < list.size(); i++){
            total = total + list.get(i);
        }
        return total/list.size();
    }





    public static void lyapunov (int time) {
        double c1 = rmass * length * length / 2 + Inertia1 / 2 + mass * length * length / 2;
        double c2 = mass * length_2 * length_2 / 2 + Inertia2 / 2;
        double c3 = mass * length * length_2;
        double c4 = rgravity * (rmass * length + mass * length);
        double c5 = rgravity * mass * length_2;
        int steps = 106;
        Number_of_cycles = steps*time;
        double c_1 = omega_mass*omega_length*omega_length/2 + omega_Inertia/2 + eta_mass*omega_length*omega_length/2;
        double c_2 = eta_mass*eta_length*eta_length/2 +eta_Inertia/2;
        double c_3 = eta_mass*omega_length*eta_length;
        double c_4 = rgravity *(omega_mass*omega_length+eta_mass*omega_length);
        double c_5 = rgravity *omega_mass*eta_length;
        eta = psi + 0.0001;
        double previous_psi   = psi;
        double previous_theta = theta;
        // This is a while loop performing two simultaneous simulations (try saying that 5 times fast) with a slight displacement in each.
        while (current_cycle < Number_of_cycles) {

            psi_dub = (mass * length * length_2 * theta_dot * psi_dot * Ball.sin(theta - psi) - mass * rgravity * length_2 * Ball.sin(psi) - mass * length * length_2 * theta_dub * Ball.cos(theta - psi) + mass * length * length_2 * theta_dot * (theta_dot - psi_dot) * Ball.sin(theta - psi)) / (Inertia2 + mass * length_2 * length_2);
            psi_dot = (psi_dot + psi_dub * dt);
            psi = (psi + psi_dot * dt);

            theta_dub = (2 * c2 * c4 * Ball.sin(theta) + c3 * c3 * theta_dot * theta_dot * Ball.sin(theta - psi) * Ball.cos(theta - psi) + 2 * c2 * c3 * psi_dot * psi_dot * Ball.sin(theta - psi) - c3 * c5 * Ball.cos(theta - psi) * Ball.sin(psi)) / (c3 * c3 * Ball.cos(theta - psi) * Ball.cos(theta - psi) - 4 * c1 * c2);
            theta_dot = (theta_dot + theta_dub * dt);
            theta = (theta + theta_dot * dt);

            eta_dub = (eta_mass*omega_length*eta_length*omega_dot*eta_dot*Ball.sin(omega-eta)-eta_mass* rgravity * eta_length*Ball.sin(eta)-eta_mass*omega_length*eta_length*omega_dub*Ball.cos(omega-eta)+eta_mass*omega_length*eta_length*omega_dot*(omega_dot-eta_dot)*Ball.sin(omega-eta))/(eta_Inertia+eta_mass*eta_length*eta_length);
            eta_dot = (eta_dot + eta_dub*dt);
            eta     = (eta + eta_dot*dt);

            omega_dub = (2*c_2*c_4*Ball.sin(omega)+c_3*c_3*omega_dot*omega_dot*Ball.sin(omega-eta)*Ball.cos(omega-eta)+2*c_2*c_3*eta_dot*eta_dot*Ball.sin(omega-eta)-c_3*c_5*Ball.cos(omega-eta)*Ball.sin(eta))/(c_3*c_3*Ball.cos(omega-eta)*Ball.cos(omega-eta)-4*c_1*c_2);
            omega_dot = (omega_dot + omega_dub*dt);
            omega     = (omega + omega_dot*dt);


            current_cycle++;
        }
        double Rx = length*Math.sin((theta));
        double Ry = length*Math.cos((theta));
        double x = length_2*(Math.sin(psi)) + Rx;
        double y = length_2*(Math.cos(psi)) + Ry;

        double omega_x = omega_length*Math.sin((omega));
        double omega_y = omega_length*Math.cos((omega));
        double eta_x = eta_length*(Math.sin(eta)) + omega_x;
        double eta_y = eta_length*(Math.cos(eta)) + omega_y;

        double Rx2 = length*Math.sin((previous_theta));
        double Ry2 = length*Math.cos((previous_theta));
        double x2 = length_2*(Math.sin(previous_psi)) + Rx2;
        double y2 = length_2*(Math.cos(previous_psi)) + Ry2;

        //We calculate the displacement to be used with the exponent calculation
        System.out.println("psi: " + psi);
        System.out.println("eta: " + eta);
        double displacement  = Math.sqrt((x - eta_x)*(x-eta_x) + (y-eta_y)*(y-eta_y));
        System.out.println("Displacement: " + displacement);
        double displacement2 = Math.sqrt((Rx-Rx2)*(Rx-Rx2)+(Ry-Ry2)*(Ry-Ry2));
        System.out.println("displacment2: "+ displacement2);
        double lambda        = (10000/steps)/Math.log(displacement/displacement2);

        Exponents.add(lambda);
        System.out.println("Lambda: " + lambda);
        Averages.add(Average_List(Exponents));




    }
    // Averages a list
    private static double Average_List(LinkedList<Double> list){
        double out  = 0;
        for(int i = 0; i < list.size(); i++){
            out = out + list.get(i);
        }
        out = out/list.size();
        return out;
    }
}
