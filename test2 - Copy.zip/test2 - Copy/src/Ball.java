import javax.swing.*;


/**
 * Created by ErikT on 08-Feb-17.
 */
class Ball extends JPanel {


    static double                     x = 500;
    static double                     y = 500;
    static int                x_bar_top = 533;
    static int                y_bar_top = 0;
    static double                 ticks = 0;
    static double                    Rx = 0;
    static double                    Ry = 0;
    public static double        omega_x = 500;
    public static double        omega_y = 500;
    public static int       omega_top_x = 533;
    public static int       omega_top_y = 0;

    /*CHANGE ME*/
    // Please also note that the notation is terrible, but I will attempt to explain. rmass means red mass, and is the pendulum attached to the central pivot
    // x_dot is the velocity of x
    // x_dub is the acceleration of x
    // Anything labelled as a 2 is attached to the second pendulum
    // Anything labelled with a 1 is attached to the first pendulum
    // I know that some of the naming conventions are sloppy coding but I repurposed it from an older program that I built to make it work for this
    // I Believe most of it is pretty self explanatory.
    //
    private static double    rgravity = 40;
    private static double      length = 100;
    private static double      theta  = toRad(120);
    static double           theta_dot = 0;
    private static double   theta_dub = 0;
    private static double       rmass = 10;
    private static double        mass = 10;
    private static double    Inertia1 = (1/12) * rmass*length*length;
    private static double    length_2 = 50;
    private static double         psi = toRad(120);
    static double             psi_dot = 0;
    private static double     psi_dub = 0;
    private static double    Inertia2 = (1/12) * mass*length_2*length_2;
    //This is used if you want to calculate the lyapunov exponents


    //The following is the code for the second set of double pendulum, designed to show the difference between the two. Set USE_TWO to true in order to see it in action.
    // It is usually set to false, as it just a proof of concept thing, demonstrating the chaotic behaviour
    // If you want, set it to true to test out
    public  static boolean      USE_TWO = false;
    private static double  omega_length = 100;
    private static double         omega = toRad(240);
    private static double     omega_dot = 0;
    private static double     omega_dub = 0;
    private static double    omega_mass = 10;
    private static double omega_Inertia = (1/12) * omega_mass*omega_length*omega_length;
    public static double          eta_x = 500;
    public static double          eta_y = 300;
    private static double    eta_length = 50;
    private static double           eta = toRad(240);
    private static double       eta_dot = 0;
    private static double       eta_dub = 0;
    private static double      eta_mass = 10;
    private static double   eta_Inertia = (1/12) * eta_mass*eta_length*eta_length;



    /*
    The following boolean switches add different analytical graphs, hopefully each one is explained properly
    please only have one of these switched on at once, because only one will work.
     */
    /*
    This is to create the chaos map component of the image. The chaos map is a map of all of the possible options
     From 0 to 180 degrees, and plots the amount of flips.
     Please note that this consumes memory much more than anything else, so it will lag... a lot. So if we use this, it will not simulate
     anythhing else apart from the chaos map. It will also take ages to load. There will be a lot of output if this is turned on, as it is to demonstrate that it is running.
     When iterations start printing out then it is essentially a countdown until it is finished.
     GIVE IT TIME IT TAKES FOREVER IT IS DOING A LOT OF CALCULATIONS
     IT HAS A HUGE RUN TIME.
     It could probably be done more efficiently
     But i didn't want to get into threading and running it on different cores and processors. If i did I probably would have used ada.
     If you are a sane human being and do not want to wait for the image to load, there is tonnes of information on what happens in the report section of the assignmnet.
     I have done many long and ardurous runs of making these really pretty chaos maps, with many pictures. I say just run it once to see if it works, and then trust me that
     all of the pretty ones that are in the assignmetn are actually correct.

     */
    // Yay, chaos :D
    static boolean CHAOS_MAP              = false;
    static boolean average_velocity_graph = false;
    static boolean  calc_lyaponuv         = false;
    static boolean Use_Poincare           = false;
    static boolean HPO                    = false;


    /*STOP CHANGING*/

    // More fun stuff below, just used for building the image and other stuff.
    // This is just information to get the maths working, and to get the flip counter, and velocity graphs up and running
    static int                 flips = 0;
    private static double         dt = 0.01;
    private static double   firstPsi = psi;
    private static double   FinalPsi = 0;

    /**
     * The following several classes are just to tidy up some of my code. Instead of having math.sqrt littered throughout everything it makes it a little bit nicer and neater.
     * They are literally just methods to make the code nicer.
     * toCorrectDomain converts an angle from out of the 0 - 360 range into the correct range. This is for simplicities sake and again so everything looks nicer.
     */
    static double sin(double angle){
        return Math.sin((angle));
    }

    static double cos(double angle){
        return Math.cos((angle));
    }

    static double toRad(double angle){
        return Math.toRadians(angle);
    }

    static double toCorrectDomain(double angle){
        while(angle >= 360){
            angle = angle -360;
        }

        while(angle <= 0){
            angle = angle + 360;
        }
        return angle;
    }
    private static int cycles = 0;

    //Calculates a lyapunov exponent for a given value. Can be changed at the top
    private static void Calculate_Lyapunov (){
        double lambda = (1/ticks)*Math.log(FinalPsi/firstPsi);
        System.out.println(lambda);

    }

    static void moveBall() {
        //Please note that the c substitutions were made here because I kept making mistakes writing the equations of motion, so this made things much easier for me.
        // They are correct as far as I can tell, and it just made life much simpler to program, even though they aren't used in the report.
        double c1 = rmass*length*length/2 + Inertia1/2 + mass*length*length/2;
        double c2 = mass*length_2*length_2/2 +Inertia2/2;
        double c3 = mass*length*length_2;
        double c4 = rgravity *(rmass*length+mass*length);
        double c5 = rgravity *mass*length_2;

        //This is the physics. Hopefully my maths is correct. Seems to work pretty accurately
        double previousPsi = psi;
        psi_dub = (mass*length*length_2*theta_dot*psi_dot*sin(theta-psi)-mass* rgravity *length_2*sin(psi)-mass*length*length_2*theta_dub*cos(theta-psi)+mass*length*length_2*theta_dot*(theta_dot-psi_dot)*sin(theta-psi))/(Inertia2+mass*length_2*length_2);
        psi_dot = (psi_dot + psi_dub*dt);
        psi     = (psi + psi_dot*dt);

        //More equations. This is where the cs come in. It was done because of the many mistakes I made putting this into the computers
        theta_dub = (2*c2*c4*sin(theta)+c3*c3*theta_dot*theta_dot*sin(theta-psi)*cos(theta-psi)+2*c2*c3*psi_dot*psi_dot*sin(theta-psi)-c3*c5*cos(theta-psi)*sin(psi))/(c3*c3*cos(theta-psi)*cos(theta-psi)-4*c1*c2);
        theta_dot = (theta_dot + theta_dub*dt);
        theta     = (theta + theta_dot*dt);

        // Converts to x and y coords.
        Rx = length*Math.sin((theta))+ 525;
        Ry = length*Math.cos((theta))+200;

        // This plots the velocities.
        if(Window.BVelocity.size()<1470) {
            if(theta_dot>4){
                Window.RVelocity.add(4.0);
            }
            else if(theta_dot<-2){
                Window.RVelocity.add(-2.0);
            }
            else {
                Window.RVelocity.add(theta_dot);
            }

            if(psi_dot>4){
                Window.BVelocity.add(4.0);
            }
            else if(psi_dot<-2){
                Window.BVelocity.add(-2.0);
            }
            else {
                Window.BVelocity.add(psi_dot);
            }
        }
        else{
            if(cycles==1470){
                cycles = 0;
            }
            if(theta_dot>4){
                Window.RVelocity.set(cycles, 4.0);
            }
            else if(theta_dot<-2){
                Window.RVelocity.set(cycles, -2.0);
            }
            else {
                Window.RVelocity.set(cycles, theta_dot);
            }

            if(psi_dot>4){
                Window.BVelocity.set(cycles, 4.0);
            }
            else if(psi_dot<-2){
                Window.BVelocity.set(cycles, -2.0);
            }
            else {
                Window.BVelocity.set(cycles, psi_dot);
            }
            cycles++;
        }
        //This is our flip counter
        double previouspsi = toCorrectDomain(Math.toDegrees(previousPsi));
        double currentpsi  = toCorrectDomain(Math.toDegrees(psi));
        if (previouspsi < 180 && currentpsi >= 180 && previouspsi > 40){
            flips++;
        }
        else if(previouspsi > 180 && currentpsi <= 180 && previouspsi < 320){
            flips++;

        }



        x = length_2*(Math.sin(psi)) + Rx;
        y = length_2*(Math.cos(psi)) + Ry;

    }

/**
 * This entire method is basically just a copy of the first one, so there isn't anything commented in here. For more detail, please see the method moveBall
 */
    static void move_Omega() {

        double c1 = omega_mass*omega_length*omega_length/2 + omega_Inertia/2 + eta_mass*omega_length*omega_length/2;
        double c2 = eta_mass*eta_length*eta_length/2 +eta_Inertia/2;
        double c3 = eta_mass*omega_length*eta_length;
        double c4 = rgravity *(omega_mass*omega_length+eta_mass*omega_length);
        double c5 = rgravity *omega_mass*eta_length;

        eta_dub = (eta_mass*omega_length*eta_length*omega_dot*eta_dot*sin(omega-eta)-eta_mass* rgravity * eta_length*sin(eta)-eta_mass*omega_length*eta_length*omega_dub*cos(omega-eta)+eta_mass*omega_length*eta_length*omega_dot*(omega_dot-eta_dot)*sin(omega-eta))/(eta_Inertia+eta_mass*eta_length*eta_length);
        eta_dot = (eta_dot + eta_dub*dt);
        eta     = (eta + eta_dot*dt);

        omega_dub = (2*c2*c4*sin(omega)+c3*c3*omega_dot*omega_dot*sin(omega-eta)*cos(omega-eta)+2*c2*c3*eta_dot*eta_dot*sin(omega-eta)-c3*c5*cos(omega-eta)*sin(eta))/(c3*c3*cos(omega-eta)*cos(omega-eta)-4*c1*c2);
        omega_dot = (omega_dot + omega_dub*dt);
        omega     = (omega + omega_dot*dt);

        omega_x = omega_length*Math.sin((omega))+ 525;
        omega_y = omega_length*Math.cos((omega))+200;


        if(Window.OVelocity.size()<1470) {
            if(omega_dot>4){
                Window.OVelocity.add(4.0);
            }
            else if(omega_dot<-2){
                Window.OVelocity.add(-2.0);
            }
            else {
                Window.OVelocity.add(omega_dot);
            }

            if(eta_dot>4){
                Window.EVelocity.add(4.0);
            }
            else if(eta_dot<-2){
                Window.EVelocity.add(-2.0);
            }
            else {
                Window.EVelocity.add(eta_dot);
            }
        }
        else{
            if(cycles==1470){
                cycles = 0;
            }
            if(omega_dot>4){
                Window.OVelocity.set(cycles, 4.0);
            }
            else if(omega_dot<-2){
                Window.OVelocity.set(cycles, -2.0);
            }
            else {
                Window.OVelocity.set(cycles, omega_dot);
            }

            if(eta_dot>4){
                Window.EVelocity.set(cycles, 4.0);
            }
            else if(eta_dot<-2){
                Window.EVelocity.set(cycles, -2.0);
            }
            else {
                Window.EVelocity.set(cycles, eta_dot);
            }
        }

        eta_x = eta_length*(Math.sin(eta)) + omega_x;
        eta_y = eta_length*(Math.cos(eta)) + omega_y;

    }


}
