/**
 * Created by ErikT on 02-Feb-17.
 * This was created on the second of february because it is a manipulation of a previous piece of code that I wrote for different purposes
 * I will put the following in front of code that can change our initial conditions:
 */

/*CHANGE ME*/ // -> THis will surround the section of code that can be changed for initial conditions.

/**
 * This is so that you don't break any important parts of the code :)
 * It will basically just be the initial variables.
 */


import sun.awt.image.ImageWatched;

import java.awt.*;

import java.util.LinkedList;
import javax.swing.*;


@SuppressWarnings("serial")
public class Window extends JPanel {
    // Comments will be put in like this, in an attempt to explain every component.

    //The following are linked lists, which contain various information about the two pendulum. The Blackdots contains the positions of blackdots, Reddots is the same.
    // Rvelocity is the velocity of the red pendulum, and simlarly BVelocity for the black pendulum
    // The other two (O & E) are for omega and eta velocities if we are simulating two pendulums at once
    // Chaos map is to build the chaos map if that option is selected.
    private static LinkedList<Integer> Blackdots = new LinkedList<>();
    private static LinkedList<Integer> Reddots   = new LinkedList<>();
    private static LinkedList<Integer> GreenDots = new LinkedList<>();
    private static LinkedList<Integer> PurpDots  = new LinkedList<>();
    static         LinkedList<Double>  RVelocity = new LinkedList<>();
    static         LinkedList<Double>  BVelocity = new LinkedList<>();
    static         LinkedList<Double>  OVelocity = new LinkedList<>();
    static         LinkedList<Double>  EVelocity = new LinkedList<>();
    private static LinkedList<Color>   CHAOSMAP  = new LinkedList<>();
    private static LinkedList<Color>        HPOT = new LinkedList<>();


    // This is the time that the program started, is initialised at 0, is delcared later.
    private static long time = 0;

    /** This method builds the screen and adds other stuff into it.
     * Most of it is just building the image, but I will do my best to explain the little details.
    **/
    @Override
    public void paint(Graphics g) {
        /**
         * The following are all just to build the image
         * */

        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);


        if(Ball.CHAOS_MAP){
            System.out.println("started");
            g2d.drawLine(250, (180+175), 700, (180+175));
            g2d.drawLine(450, 150, 450, (360+175+25));
            g2d.drawString("180 degrees", 200, (180+175-15));
            g2d.drawString("180 degrees", 410, 130);
            int row = 0;
            int subtract = 0;
            for(int i = 0; i < CHAOSMAP.size(); i++){
                if(i % 360 == 0){
                    row++;
                    subtract = subtract+360;
                }
                System.out.println("Iterations left: " + (CHAOSMAP.size()-i));

                g2d.setColor(CHAOSMAP.get(i));
                g2d.drawLine(i-subtract+640, row+175, i-subtract+640, row+175);
            }
        }
        else if(Ball.HPO){
            System.out.println("started");
            g2d.drawLine(250, (180+175), 700, (180+175));
            g2d.drawLine(450, 150, 450, (360+175+25));
            g2d.drawString("0 Radians", 200, (180+175-15));
            g2d.drawString("0 Radians", 410, 130);
            int row = 0;
            int subtract = 0;
            System.out.println("HPOT SIZE = " + HPOT.size());
            for(int i = 0; i < HPOT.size(); i++){
                if(i % 360 == 0){
                    row++;
                    subtract = subtract+360;
                }
                System.out.println("Iterations left: " + (HPOT.size()-i));

                g2d.setColor(HPOT.get(i));
                g2d.drawLine(i-subtract+640, row+175, i-subtract+640, row+175);
            }
            System.out.println("done");
        }
        else if(Ball.average_velocity_graph){
            // This will create a graph of all of the average velocities for each of the possible lengths. It is going to do 50 different variations of length for the second rod.
            // Then it will plot the velocities of the lengths with average velocity, hopefully coming up with something prettty cool. It is important to note that it will take the magnitude of the velocity,
            // not the actual velocity itself.
            g2d.drawString("Plot of average velocity versus length of second arm", 350, 30);
            g2d.drawLine(50, 300, 850, 300);
            g2d.drawLine(50, 70, 50, 400);
            g2d.drawLine(450, 300, 450, 310);
            g2d.drawString("Length", 430, 350);
            g2d.drawString("Average", 5, 200);
            g2d.drawString("Velocity", 5, 225);
            g2d.drawString((800/4) + " units", 240, 320);
            g2d.drawString(400 + " units", 440, 320);
            g2d.drawString((3*800/4) + " units", 640, 320);
            for(int i = 80; i < 300; i+=10){
                g2d.fillOval(250, i, 2, 2);
                g2d.fillOval(450, i, 2, 2);
                g2d.fillOval(650, i, 2, 2);
            }
            for(int i = 50; i < 850; i+= 10){
                g2d.fillOval(i, 120, 2, 2);
                g2d.fillOval(i, 230, 2, 2);
            }
            for(int i = 1; i < 800; i++){
                System.out.println("Iterations left:" + (800-i));
                double v = VelocityGraph.average_velocity(i);
                g2d.fillOval(i+50, (int) (300 + v*1.4), 3, 3);
            }
        }
        else if(Ball.Use_Poincare){
            g2d.drawString("Poincare Plot", 350, 30);
            g2d.drawLine(50, 300, 850, 300);
            g2d.drawLine(50, 70, 50, 400);
            for(double i = 0; i < 360; i+=0.25){
                System.out.println("Iterations left: " + i);
                for(double j = 0; j < 500; j+=2){
                    if(Poincare.poincare(i, j)){
                        g2d.drawLine((int) (4*i)+50,  ((int) j/2)+150, (int) (4*i)+50, ((int) j/2)+150);
                    }
                }
            }
        }
        else if(Ball.calc_lyaponuv){
            g2d.drawString("Lyaponuv Graph", 350, 30);
            g2d.drawLine(50, 300, 850, 300);
            g2d.drawLine(50, 70, 50, 400);
            g2d.drawLine(450, 300, 450, 310);
            g2d.drawString("Displacement", 430, 350);
            g2d.drawString("Lyaponuv", 5, 200);
            g2d.drawString("exponent", 5, 225);
            for(int i = 80; i < 300; i+=10){
                g2d.fillOval(250, i, 2, 2);
                g2d.fillOval(450, i, 2, 2);
                g2d.fillOval(650, i, 2, 2);
            }
            for(int i = 50; i < 850; i+= 10){
                g2d.fillOval(i, 120, 2, 2);
                g2d.fillOval(i, 230, 2, 2);
            }
            int px = 50;
            int py = 450;
            for(int i = 1; i < 800; i++){
                System.out.println("Iterations Left: " + (800-i));
                Lyaponuv.lyapunov(i);
                /*g2d.fillOval((i+50), (int) (300 - (v*1000)), 3, 3);
                px = (i+50);
                py = (int) (300 - v*100);*/
            }
            int previousx = 50;
            int previousy = 450;
            for(int i = 0; i < 799; i++){
                double plot = Lyaponuv.Averages.get(i);
                g2d.fillOval((i+50), (int) (300 - (plot)), 3, 3);
                g2d.drawLine(previousx, previousy, (i+50), (int) (300-plot));
                previousx = i + 50;
                previousy = (int) (300 - (plot));

            }

            System.out.println("Average Exponent: " + Lyaponuv.Average(Lyaponuv.Exponents));
        }
        else {
            //Sets the color of the first ball
            g2d.setColor(Color.black);
            //This draws the first ball based on the position in The Ball class.
            g2d.fillOval((int) Ball.x, (int) Ball.y, 15, 15);
            // Draws the line that connects the pendulum to the 'hinge' point
            g2d.drawLine((int) Ball.Rx + 7, (int) Ball.Ry + 7, (int) Ball.x + 7, (int) Ball.y + 7);
            // Adds some information in the top left hand corner so that I could debug. If it is still in it just changes the number based on whatever the current values are.
            g2d.drawString("Time: " + (System.currentTimeMillis() - time) / 1000.0, 30, 30);
            g2d.drawString("Angular Velocity 1: " + Ball.theta_dot, 30, 45);
            g2d.drawString("Angular Velocity 2: " + Ball.psi_dot, 30, 60);
            g2d.drawString("Number of flips: " + Ball.flips, 30, 75);

            //This loop plots all of the positions of the black pendulum, drawing the picture on the screen
            for (int i = 0; i < Blackdots.size(); i++) {
                 int dot = Blackdots.get(i);
                    int x = (dot / 10000);
                    int y = dot - x * 10000;
                    g2d.fillOval(x, y, 6, 6);

                }

                // This is the bit which plots the graph on the bottom. It draws data from the two linked lists mentioned earlier.
                for (int i = 0; i < BVelocity.size(); i++) {

                    int pos = (i / 2);
                    g2d.setColor(Color.black);
                    g2d.fillOval(pos, (int) (500.0 + (BVelocity.get(i)/2) * 100), 3, 3);
                    g2d.setColor(Color.RED);
                    g2d.fillOval(pos, (int) (500.0 + (RVelocity.get(i)/2) * 100), 3, 3);

                }
                //Changes colour to red so we can distinguish between the two pendulums, then draws all the positions of the two pendulu, It also draws a line connecting the two pendulum.
                g2d.setColor(Color.RED);
                g2d.fillOval((int) Ball.Rx, (int) Ball.Ry, 15, 15);
                g2d.drawLine(Ball.x_bar_top, Ball.y_bar_top + 200, (int) Ball.Rx + 7, (int) Ball.Ry + 7);
        /*for(int i =0; i<Reddots.size(); i++){
            int dot = Reddots.get(i);
            int x   = (dot/10000);
            int y   = dot - x*10000;
            g2d.fillOval(x, y, 6, 6);

        }*/


                g2d.setColor(Color.LIGHT_GRAY);
                g2d.fillRect(800, 0, 400, 400);

                g2d.setColor(Color.black);
                g2d.drawRect(800, 0, 400, 400);
                g2d.drawLine(0, 400, 800, 400);
                g2d.drawLine(0, 500, 800, 500);
                g2d.drawRect(800, 400, 400, 400);
                g2d.drawString("Time", 15, 490);
                g2d.drawLine(490, 400, 490, 800);
                g2d.drawString("10.0s", 495, 490);
                g2d.drawLine(245, 400, 245, 800);
                g2d.drawString("5.0s", 250, 490);
                g2d.drawLine(245 + 490, 400, 245 + 490, 800);
                g2d.drawString("15.0s", 490 + 250, 490);
                //Will draw the second pendulum if it is wanted
                if (Ball.USE_TWO) {
                    g2d.setColor(Color.GREEN);
                    g2d.fillOval((int) Ball.omega_x, (int) Ball.omega_y, 15, 15);
                    g2d.drawLine(Ball.omega_top_x, Ball.omega_top_y + 200, (int) Ball.omega_x + 7, (int) Ball.omega_y + 7);
            /*for(int i =0; i<GreenDots.size(); i++){

                int dot = GreenDots.get(i);
                int x   = (dot/10000);
                int y   = dot - x*10000;
                g2d.fillOval(x, y, 6, 6);

            }*/
                    g2d.setColor(Color.MAGENTA);
                    g2d.fillOval((int) Ball.eta_x, (int) Ball.eta_y, 15, 15);
                    g2d.drawLine((int) Ball.omega_x + 7, (int) Ball.omega_y + 7, (int) Ball.eta_x + 7, (int) Ball.eta_y + 7);
                    for (int i = 0; i < PurpDots.size(); i++) {
                        int dot = PurpDots.get(i);
                        int x = (dot / 10000);
                        int y = dot - x * 10000;
                        g2d.fillOval(x, y, 6, 6);

                    }
                    for (int i = 0; i < OVelocity.size(); i++) {

                        int pos = (i / 2);
                        g2d.setColor(Color.GREEN);
                        g2d.fillOval(pos, (int) (500.0 + (OVelocity.get(i)/2) * 100), 3, 3);
                        g2d.setColor(Color.MAGENTA);
                        g2d.fillOval(pos, (int) (500.0 + (EVelocity.get(i)/2) * 100), 3, 3);

                    }
                }

            }
        }





    private static void moveBall(){
        Ball.moveBall();
    }
    private static void moveOmega() { Ball.move_Omega();}


    private static int number_of_cycles = 0;

    //This is the main method which brings everything together. It is essentially all just building everything, however
    // There is a little bit of tricky stuff, such as storing information
    public static void main(String[] args) throws InterruptedException {

        JFrame frame = new JFrame("Sample Frame");
        Window game = new Window();
        frame.add(game);
        int height = 720;
        int width = 1080;
        frame.setSize(width, height);
        frame.setVisible(true);
        frame.setBackground(Color.LIGHT_GRAY);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        time = System.currentTimeMillis();
        if (Ball.CHAOS_MAP) {
            frame.setTitle("Chaos Map");
            for (double i = 0; i < 360; i += 1) {
                for (double j = 0; j < 360; j += 1) {
                    Color out = Chaos.colour_of_chaos(i, j);
                    CHAOSMAP.add(out);
                }
            }
           game.repaint();

        }
        else if(Ball.average_velocity_graph){
            frame.setTitle("Velocity graph");
            game.repaint();
        }
        else if(Ball.calc_lyaponuv){
            frame.setTitle("Lyaponuv graph");
            game.repaint();
        }
        else if(Ball.Use_Poincare){
            frame.setTitle("Poincare");
            game.repaint();
        }
        else if(Ball.HPO){
            frame.setTitle("HPO");
            for (int i = -180; i < 180; i ++) {
                for (int j = -180; j < 180; j ++) {
                    Color out = HPO.time(i, j);
                    HPOT.add(out);
                }
            }
            game.repaint();
        }
        else {
            frame.setTitle("Pendulum simulation");
            while (true) {
                moveBall();
                if (Ball.USE_TWO) {
                    moveOmega();
                }

                Ball.ticks++;
                if (Ball.ticks % 10 == 0) {
                    int x1 = (int) Ball.x;
                    int y1 = (int) Ball.y;
                    int x2 = (int) Ball.Rx;
                    int y2 = (int) Ball.Ry;
                    int comb1 = x1 * 10000 + y1;
                    int comb2 = x2 * 10000 + y2;
                    if (Blackdots.size() == 200) {
                        if (number_of_cycles == 200) {
                            number_of_cycles = 0;
                        }
                        Blackdots.set(number_of_cycles, comb1);
                        Reddots.set(number_of_cycles, comb2);
                        if (Ball.USE_TWO) {
                            int x_1 = (int) Ball.omega_x;
                            int y_1 = (int) Ball.omega_y;
                            int x_2 = (int) Ball.eta_x;
                            int y_2 = (int) Ball.eta_y;
                            int comb_1 = x_1 * 10000 + y_1;
                            int comb_2 = x_2 * 10000 + y_2;
                            GreenDots.set(number_of_cycles, comb_1);
                            PurpDots.set(number_of_cycles, comb_2);

                        }
                    } else {
                        Blackdots.add(comb1);
                        Reddots.add(comb2);
                        if (Ball.USE_TWO) {
                            int x_1 = (int) Ball.omega_x;
                            int y_1 = (int) Ball.omega_y;
                            int x_2 = (int) Ball.eta_x;
                            int y_2 = (int) Ball.eta_y;
                            int comb_1 = x_1 * 10000 + y_1;
                            int comb_2 = x_2 * 10000 + y_2;
                            GreenDots.add(comb_1);
                            PurpDots.add(comb_2);

                        }
                    }
                    number_of_cycles++;

                }
                game.repaint();

                Thread.sleep(10);
            }
        }
    }


}
